var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./FileExplorer/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./FileExplorer/index.ts":
/*!*******************************!*\
  !*** ./FileExplorer/index.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n/*\r\n//https://github.com/redbooth/free-file-icons\r\n * The MIT License (MIT)\r\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation\r\nfiles (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy,\r\nmodify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the\r\nSoftware is furnished to do so, subject to the following conditions:\r\n\r\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the\r\nSoftware.\r\n\r\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE\r\nWARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR\r\nCOPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,\r\nARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\r\n */\n\nvar Downloadfile =\n/** @class */\nfunction () {\n  function Downloadfile() {}\n\n  return Downloadfile;\n}();\n\nvar EntityReference =\n/** @class */\nfunction () {\n  function EntityReference(typeName, id) {\n    this.id = id;\n    this.typeName = typeName;\n  }\n\n  return EntityReference;\n}();\n\nvar Item =\n/** @class */\nfunction () {\n  function Item(groupId, attachmentId, groupName, name, extension, size) {\n    this.attachmentId = attachmentId;\n    this.groupId = groupId;\n    this.groupName = groupName;\n    this.name = name;\n    this.size = size;\n    this.extension = extension;\n  }\n\n  return Item;\n}();\n\nvar FileExplorer =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function FileExplorer() {\n    this._groupElements = [];\n    this._itemElements = [];\n  }\n  /**\r\n   * Render table with items\r\n   * @param items\r\n   * items to render\r\n   */\n\n\n  FileExplorer.prototype.renderTable = function (items) {\n    if (items.length > 0) {\n      var divControl = document.createElement(\"div\");\n      divControl.className = \"control\";\n\n      this._container.appendChild(divControl);\n\n      var groupId = '-';\n      var i = 0;\n\n      do {\n        if (items[i].groupId != null && items[i].groupId.id != groupId) {\n          //add new group\n          this.addGroup(divControl, items[i]);\n          groupId = items[i].groupId.id;\n        } //add item\n\n\n        this.addItem(divControl, items[i]);\n        i++;\n      } while (i < items.length);\n    }\n  };\n  /**\r\n   * Add group\r\n   * @param control\r\n   * Control where group will be added\r\n   * @param item\r\n   * Item to render\r\n   */\n\n\n  FileExplorer.prototype.addGroup = function (control, item) {\n    var _this = this; //create title\n\n\n    var divTitle = document.createElement(\"div\");\n    divTitle.className = \"group\";\n\n    if (item.groupName == '') {\n      divTitle.innerText = \"Attachments\";\n    } else {\n      divTitle.innerText = item.groupName;\n\n      divTitle.onclick = function (e) {\n        _this.openEntity(item.groupId);\n      };\n\n      this._groupElements.push(divTitle);\n    }\n\n    control.appendChild(divTitle);\n  };\n  /**\r\n   * Add item\r\n   * @param control\r\n   * Control where item will be added\r\n   * @param item\r\n   * Item to render\r\n   */\n\n\n  FileExplorer.prototype.addItem = function (control, item) {\n    var _this = this;\n\n    var divItem = document.createElement(\"div\");\n    divItem.className = \"item\";\n\n    divItem.onclick = function (e) {\n      _this.onClickAttachment(item.attachmentId);\n    };\n\n    control.appendChild(divItem);\n\n    this._itemElements.push(divItem);\n\n    var tblItem = document.createElement(\"table\");\n    divItem.appendChild(tblItem);\n    var imgRow = tblItem.insertRow();\n    var imgCell = imgRow.insertCell();\n    var img = document.createElement(\"img\"); //add image\n\n    var res = this._context.resources.getResource(item.extension + \".png\", this.setImage.bind(this, img, \"png\"), this.showError.bind(this));\n\n    imgCell.appendChild(img); //add subtitle\n\n    var subTitleRow = tblItem.insertRow();\n    var subTitleCell = subTitleRow.insertCell();\n    subTitleCell.innerText = item.name;\n  };\n  /**\r\n   * When clicked on attachment, start download\r\n   * @param reference\r\n   * EntityReference to download\r\n   */\n\n\n  FileExplorer.prototype.onClickAttachment = function (reference) {\n    var _this = this;\n\n    this.downloadAttachment(reference).then(function (f) {\n      _this._context.navigation.openFile(f);\n    });\n  };\n  /**\r\n   * Open entity form\r\n   * @param reference\r\n   * EntityReference to open\r\n   */\n\n\n  FileExplorer.prototype.openEntity = function (reference) {\n    var entityFormOptions = {};\n    entityFormOptions[\"entityName\"] = reference.typeName;\n    entityFormOptions[\"entityId\"] = reference.id;\n\n    this._context.navigation.openForm(entityFormOptions);\n  };\n  /**\r\n   * Download the attachment\r\n   * @param reference\r\n   * EntityReference to download\r\n   */\n\n\n  FileExplorer.prototype.downloadAttachment = function (reference) {\n    debugger;\n    return this._context.webAPI.retrieveRecord(reference.typeName, reference.id).then(function success(result) {\n      var file = new Downloadfile();\n      file.fileContent = reference.typeName == \"annotation\" ? result[\"documentbody\"] : result[\"body\"];\n      file.fileName = result[\"filename\"];\n      file.fileSize = result[\"filesize\"];\n      file.mimeType = result[\"mimetype\"];\n      return file;\n    });\n  };\n  /**\r\n   * Add image url\r\n   * @param element\r\n   * Element that contains the url\r\n   * @param fileType\r\n   * Type of the file\r\n   * @param fileContent\r\n   * Content of the file\r\n   */\n\n\n  FileExplorer.prototype.setImage = function (element, fileType, fileContent) {\n    var imageUrl = this.generateImageSrcUrl(fileType, fileContent);\n    element.src = imageUrl;\n  };\n  /***\r\n   * create source of file\r\n   * @param fileType\r\n   * filetype\r\n   * @param fileContent\r\n   * content\r\n   */\n\n\n  FileExplorer.prototype.generateImageSrcUrl = function (fileType, fileContent) {\n    return \"data:image/\" + fileType + \";base64, \" + fileContent;\n  };\n  /**\r\n   * log error\r\n   */\n\n\n  FileExplorer.prototype.showError = function () {\n    console.log('error while downloading .png');\n  };\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  FileExplorer.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this; // Add control initialization code\n    // assigning environment variables. \n\n\n    this._context = context;\n    this._container = container; //when we associate to lookup then lookup record's attachments and e-mail attachments\n\n    if (this._context.parameters.hidden.type.indexOf('Lookup') == 0) {\n      var ref = context.parameters.hidden.raw;\n\n      if (ref && ref.length > 0) {\n        var reference = new EntityReference(ref[0].LogicalName, ref[0].id);\n        this.getAttachments(reference).then(function (r) {\n          return _this.renderTable(r);\n        });\n        this.getRelatedEmailAttachments(reference).then(function (r) {\n          return _this.renderTable(r);\n        });\n      }\n    } else {\n      //get current record's attachments and e-mail attachments\n      var reference = new EntityReference(context.page.entityTypeName, context.page.entityId);\n\n      if (context.page.entityId != null) {\n        this.getAttachments(reference).then(function (r) {\n          return _this.renderTable(r);\n        });\n        this.getRelatedEmailAttachments(reference).then(function (r) {\n          return _this.renderTable(r);\n        });\n      }\n    }\n  };\n  /**\r\n   * Get the e-mail attachmentd\r\n   * @param reference\r\n   * Object that contains e-mails\r\n   */\n\n\n  FileExplorer.prototype.getRelatedEmailAttachments = function (reference) {\n    var xml = '<fetch><entity name=\"activitymimeattachment\"><attribute name=\"activityid\"/><attribute name=\"activitymimeattachmentid\"/><attribute name=\"activitysubject\"/><attribute name=\"filename\"/><attribute name=\"filesize\"/><link-entity name=\"email\" from=\"activityid\" to=\"objectid\" link-type=\"inner\"><attribute name=\"createdon\"/><attribute name=\"directioncode\"/><attribute name=\"activityid\"/><attribute name=\"regardingobjectid\"/><filter type=\"and\"><condition attribute=\"regardingobjectid\" operator=\"eq\" value=\"[OBJECTID]\"/></filter></link-entity></entity></fetch >';\n    xml = xml.replace('[OBJECTID]', reference.id);\n    var query = '?fetchXml=' + encodeURIComponent(xml);\n    return this._context.webAPI.retrieveMultipleRecords(\"activitymimeattachment\", query).then(function success(result) {\n      var items = [];\n\n      for (var i = 0; i < result.entities.length; i++) {\n        var ent = result.entities[i];\n        var it = new Item(new EntityReference(\"email\", ent[\"email1.activityid\"].toString()), new EntityReference(\"activitymimeattachment\", ent[\"activitymimeattachmentid\"].toString()), new Date(ent[\"email1.createdon\"]).toLocaleDateString() + \" \" + ent[\"activitysubject\"], ent[\"filename\"].split('.')[0], ent[\"filename\"].split('.')[1], ent[\"filesize\"]);\n        items.push(it);\n      }\n\n      return items;\n    }, function (error) {\n      console.log(error.message);\n      var items = [];\n      return items;\n    });\n  };\n  /**\r\n   * Get attachment items\r\n   * @param reference\r\n   * EntityReference to get the attachments of\r\n   */\n\n\n  FileExplorer.prototype.getAttachments = function (reference) {\n    var query = \"?$select=annotationid,filename,filesize,mimetype&$filter=filename ne null and _objectid_value eq \" + reference.id + \" and objecttypecode eq '\" + reference.typeName + \"' &$orderby=createdon desc\";\n    return this._context.webAPI.retrieveMultipleRecords(\"annotation\", query).then(function success(result) {\n      var items = [];\n\n      for (var i = 0; i < result.entities.length; i++) {\n        var ent = result.entities[i];\n        var it = new Item(null, new EntityReference(\"annotation\", ent[\"annotationid\"].toString()), \"\", ent[\"filename\"].split('.')[0], ent[\"filename\"].split('.')[1], ent[\"filesize\"]);\n        items.push(it);\n      }\n\n      return items;\n    }, function (error) {\n      console.log(error.message);\n      var items = [];\n      return items;\n    });\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  FileExplorer.prototype.updateView = function (context) {};\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  FileExplorer.prototype.destroy = function () {\n    var _this = this;\n\n    if (this._itemElements != null) {\n      for (var i = 0; i < this._itemElements.length; i++) {\n        this._itemElements[i].removeEventListener(\"click\", function (e) {\n          _this.onClickAttachment;\n        });\n      }\n    }\n\n    if (this._groupElements != null) {\n      for (var i = 0; i < this._groupElements.length; i++) {\n        this._groupElements[i].removeEventListener(\"click\", function (e) {\n          _this.openEntity;\n        });\n      }\n    }\n  };\n\n  return FileExplorer;\n}();\n\nexports.FileExplorer = FileExplorer;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./FileExplorer/index.ts?");

/***/ })

/******/ });
var DynamicTouch = DynamicTouch || {};
DynamicTouch.CustomControls = DynamicTouch.CustomControls || {};
DynamicTouch.CustomControls.FileExplorer = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FileExplorer;
pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;